#!/usr/bin/env python3
"""Read an Olist CSV with PySpark, write Parquet, upload files to Blob Storage."""
import argparse
import os
import shutil
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path

from azure.core.exceptions import ResourceExistsError
from azure.storage.blob import BlobServiceClient
from pyspark.sql import SparkSession
from pyspark.sql.functions import current_timestamp, lit

DATASETS = {
    "customers": "olist_customers_dataset.csv",
    "geolocation": "olist_geolocation_dataset.csv",
    "order_items": "olist_order_items_dataset.csv",
    "order_payments": "olist_order_payments_dataset.csv",
    "order_reviews": "olist_order_reviews_dataset.csv",
    "orders": "olist_orders_dataset.csv",
    "products": "olist_products_dataset.csv",
    "sellers": "olist_sellers_dataset.csv",
    "category_translation": "product_category_name_translation.csv",
}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", required=True, choices=sorted(DATASETS))
    parser.add_argument("--input-dir", default=os.getenv("OLIST_INPUT_DIR", "/opt/airflow/data/olist"))
    parser.add_argument("--batch-date", default=datetime.now(timezone.utc).date().isoformat())
    args = parser.parse_args()

    source_name = DATASETS[args.dataset]
    source_path = Path(args.input_dir) / source_name
    if not source_path.is_file():
        raise FileNotFoundError(f"Missing {source_path}; put the extracted Olist CSVs in data/olist/")

    connection_string = os.environ["AZURE_STORAGE_CONNECTION_STRING"]
    container_name = os.getenv("AZURE_STORAGE_CONTAINER", "bronze")
    batch_id = str(uuid.uuid4())

    spark = (SparkSession.builder.appName(f"olist-bronze-{args.dataset}")
             .master("local[2]")
             .config("spark.driver.memory", "1g")
             .config("spark.sql.session.timeZone", "UTC")
             .config("spark.ui.enabled", "false")
             .getOrCreate())
    spark.sparkContext.setLogLevel("WARN")
    temp_dir = tempfile.mkdtemp(prefix=f"olist-{args.dataset}-")
    try:
        df = (spark.read.option("header", "true").option("inferSchema", "false")
              .option("encoding", "UTF-8").csv(str(source_path))
              .withColumn("_ingested_at", current_timestamp())
              .withColumn("_source_file", lit(source_name))
              .withColumn("_dataset", lit(args.dataset))
              .withColumn("_batch_id", lit(batch_id))
              .withColumn("_batch_date", lit(args.batch_date)))
        rows = df.count()
        if rows == 0:
            raise ValueError(f"{source_name} contains no data rows")

        output_dir = str(Path(temp_dir) / "parquet")
        df.write.mode("overwrite").parquet(output_dir)

        service = BlobServiceClient.from_connection_string(connection_string)
        container = service.get_container_client(container_name)
        try:
            container.create_container()
        except ResourceExistsError:
            pass

        prefix = f"bronze/{args.dataset}/batch_date={args.batch_date}/"
        # Replacing the date prefix makes reruns idempotent for that dataset/date.
        for blob in container.list_blobs(name_starts_with=prefix):
            container.delete_blob(blob.name)

        uploaded = 0
        for path in Path(output_dir).rglob("*"):
            if path.is_file() and path.name != "_SUCCESS":
                name = prefix + path.relative_to(output_dir).as_posix()
                with path.open("rb") as stream:
                    container.upload_blob(name=name, data=stream, overwrite=True)
                uploaded += 1

        print(f"SUCCESS dataset={args.dataset} rows={rows} uploaded_files={uploaded} container={container_name} prefix={prefix} batch_id={batch_id}")
    finally:
        spark.stop()
        shutil.rmtree(temp_dir, ignore_errors=True)

if __name__ == "__main__":
    main()
