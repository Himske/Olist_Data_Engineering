# Olist Data Platform — PySpark, Airflow and Azurite

A Docker Compose local data engineering project. Airflow orchestrates nine
PySpark tasks. Each reads one Olist CSV, adds ingestion metadata, writes
Parquet locally, and uploads the files to an Azurite Blob container through
the Azure Storage SDK.

## Services
- Airflow 2.10.5 — scheduling and orchestration
- PySpark 3.5.3 / Java 17 — processing and Parquet
- Azurite — local Azure Blob Storage emulator
- PostgreSQL 16 — Airflow metadata database

### Why Spark writes locally before upload
Spark runs in local mode inside the Airflow container. The job writes Parquet
to a temporary directory and uploads the output files using the Azure Blob
SDK. This avoids Hadoop Azure connector/emulator endpoint compatibility
issues while using the actual Azure Blob API and an Azure-style container /
object layout.

## 1. Prerequisites
- Docker Engine/Desktop and Docker Compose plugin
- 6 GB RAM available to Docker (8 GB recommended)
- Olist CSV dataset downloaded from Kaggle

## 2. Prepare
Copy `.env.example` to `.env`, then create the mount directories:

```bash
cp .env.example .env
mkdir -p logs plugins data/olist
```

On Linux, set `AIRFLOW_UID` in `.env` to the result of `id -u`.
Extract the nine Olist CSVs directly into `data/olist/`. Expected filenames
are in `data/olist/README.md`.

The Azurite account and key are public development credentials. Never use
them for production or real Azure resources.

## 3. Build and start

```bash
docker compose build
docker compose up airflow-init
docker compose up -d
```

Airflow UI: http://localhost:8080
Default local login: `admin` / `admin` (change in `.env` before sharing).

Azurite endpoint from the host: `http://127.0.0.1:10000/devstoreaccount1`
From containers use `http://azurite:10000/devstoreaccount1`.

The `bronze` container is created by the first successful ingestion task.

## 4. Test one dataset

```bash
docker compose exec airflow-scheduler \
  spark-submit --master 'local[2]' \
  --conf spark.driver.memory=1g \
  /opt/airflow/spark/olist_ingest.py --dataset orders --batch-date 2026-11-17
```

Or enable and trigger `olist_bronze_ingestion` in the Airflow UI. It runs
daily at 03:00 UTC and has one task per CSV.

## 5. Verify output

Use Azure Storage Explorer and connect to the local emulator, or run:

```bash
docker compose exec airflow-scheduler python - <<'PY'
import os
from azure.storage.blob import BlobServiceClient
service = BlobServiceClient.from_connection_string(os.environ["AZURE_STORAGE_CONNECTION_STRING"])
container = service.get_container_client(os.getenv("AZURE_STORAGE_CONTAINER", "bronze"))
for blob in container.list_blobs(name_starts_with="bronze/orders/"):
    print(blob.name, blob.size)
PY
```

Expected object layout:

```text
bronze/orders/batch_date=YYYY-MM-DD/part-....snappy.parquet
bronze/customers/batch_date=YYYY-MM-DD/part-....snappy.parquet
...
```

## 6. Useful commands

```bash
docker compose ps
docker compose logs -f airflow-scheduler
docker compose logs -f azurite
docker compose down       # preserve volumes
docker compose down -v    # delete local database and Azurite data
```

## Notes
- CSV columns are initially strings; apply explicit types and data-quality
  checks in a Silver layer.
- Reruns replace the objects for the same dataset/date prefix. This is
  idempotent at the date-prefix level, but not a transactional multi-object
  commit if an upload fails halfway through.
- This starter intentionally focuses on Bronze ingestion. Add dbt after
  selecting a query engine/warehouse (DuckDB is a lightweight local option).
- The Compose setup is for local development, not production deployment.

## Troubleshooting
- **Missing CSV:** ensure files are directly in `data/olist/`.
- **Java gateway error:** rebuild using `docker compose build --no-cache`.
- **Azurite refused:** containers must use `azurite:10000`, not localhost.
- **Log permission errors:** on Linux set `AIRFLOW_UID=$(id -u)` in `.env`.
