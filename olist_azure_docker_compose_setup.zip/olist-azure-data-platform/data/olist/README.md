# Olist source data

Download the Olist Brazilian E-Commerce Public Dataset from Kaggle and extract
the CSVs directly into this directory. Expected files:

- olist_customers_dataset.csv
- olist_geolocation_dataset.csv
- olist_order_items_dataset.csv
- olist_order_payments_dataset.csv
- olist_order_reviews_dataset.csv
- olist_orders_dataset.csv
- olist_products_dataset.csv
- olist_sellers_dataset.csv
- product_category_name_translation.csv

Check the dataset license before redistributing raw data.
