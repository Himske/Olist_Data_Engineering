from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash import BashOperator

DATASETS = [
    "customers", "geolocation", "order_items", "order_payments",
    "order_reviews", "orders", "products", "sellers", "category_translation",
]
with DAG(
    dag_id="olist_bronze_ingestion",
    description="Ingest Olist CSVs as Parquet into Azurite/Azure Blob Storage",
    default_args={"owner": "data-engineering", "retries": 2, "retry_delay": timedelta(minutes=3)},
    start_date=datetime(2024, 1, 1),
    schedule="0 3 * * *",
    catchup=False,
    max_active_runs=1,
    max_active_tasks=2,
    tags=["olist", "pyspark", "azure-blob", "bronze"],
) as dag:
    for dataset in DATASETS:
        BashOperator(
            task_id=f"ingest_{dataset}",
            bash_command=(
                "spark-submit --master 'local[2]' --conf spark.driver.memory=1g "
                "--conf spark.ui.enabled=false "
                f"/opt/airflow/spark/olist_ingest.py --dataset {dataset} "
                "--batch-date '{{ ds }}'"
            ),
            execution_timeout=timedelta(hours=1),
        )
